                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3120914
Klingon D6 1/1000 by Evildave is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is the Klingon D6 from Masao Okazaki's "The Starfleet Museum" originally modeled (and posted with his permission) by Kev R. on 3Dwarehouse here:

https://3dwarehouse.sketchup.com/model/d861de9e-d2fe-4396-b8d6-0b43b77685ee/Klingon-D6-ship-collection

I broke it into 4 parts that fit together.  I also added a tube in the neck for a carbon rod or dowel.

The only known issues are:
1) The angled bits on the impulse block like to print hollow but I find that they print well enough on high quality that it just needs a dab of model filler on the ends and it's fine.

2) parts of the head and neck tend to print hollow and weak, I discovered that if you print it horizontally at high quality it not only prints faster but much stronger, just a a dap or two of model filler on the top just behind the bridge if you feel you need it.

# Print Settings

Printer Brand: XYZprinting
Printer: da Vinci miniMaker
Rafts: No
Supports: Yes
Resolution: .1
Infill: 20%~30%
Filament_brand: Shaxon
Filament_color: White
Filament_material: PLA

Notes: 
I recommend high settings for better part strength.