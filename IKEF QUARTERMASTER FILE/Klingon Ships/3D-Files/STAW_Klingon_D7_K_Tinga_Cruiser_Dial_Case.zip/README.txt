                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1732962
ST:AW Klingon D7/K'Tinga Cruiser Dial Case by KineticGothicTank is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

A maneuvering dial holder, styled as a Klingon LCARS display, Intended for a D7/K'tinga cruiser, but good for any Attack Wing dial. 

The Klingon at the top reads, "KTINGA" or "D7" in old style Klingonaase on their respective cases

The dial holder can be used either by flipping it over, or using the triangular chip to cover the dial display. The dial holder also serves as a between game display stand, the prongs on the left hand side hold your captain's tabs, while the peg hole on the silhouette of the cruiser hold the ship on a flying peg.

<a href="http://www.thingiverse.com/thing:1759058">Alternate Klingon Dial Holder Tops</a> for other Klingon ships are here.

# How I Designed This

Drawn in Adobe Illustrator, then imported to 123d as an SVG, and lofted.